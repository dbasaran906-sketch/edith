Model dosyasi (hand_landmarker.task) GitHub Actions tarafindan derleme sirasinda buraya indirilir.
