package com.elhareket.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.elhareket.app.ui.HandIcon
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { AppTheme { Root() } }
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme()) {
        darkColorScheme(primary = Color(0xFF4FD1C5), onPrimary = Color(0xFF003733))
    } else {
        lightColorScheme(primary = Color(0xFF0F766E))
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

private fun hasCamera(c: Context) =
    ContextCompat.checkSelfPermission(c, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

private fun hasNotif(c: Context) =
    Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

@Composable
fun Root() {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        if (Prefs.enabled(ctx) && hasCamera(ctx) && !GestureState.running.value) GestureService.start(ctx)
    }

    Scaffold(bottomBar = {
        NavigationBar {
            NavigationBarItem(
                selected = tab == 0, onClick = { tab = 0 },
                icon = { Icon(Icons.Filled.Settings, null) }, label = { Text("Ayarlar") },
            )
            NavigationBarItem(
                selected = tab == 1, onClick = { tab = 1 },
                icon = { Icon(Icons.Filled.Info, null) }, label = { Text("Bilgi") },
            )
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (tab == 0) SettingsScreen() else InfoScreen()
        }
    }
}

@Composable
fun StatusRow(title: String, ok: Boolean, actionLabel: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Medium)
            Text(
                if (ok) "Açık" else "Kapalı",
                color = if (ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall,
            )
        }
        if (!ok) OutlinedButton(onClick = onClick) { Text(actionLabel) }
    }
}

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(o)
        onDispose { owner.lifecycle.removeObserver(o) }
    }

    val running by GestureState.running.collectAsState()
    val current by GestureState.current.collectAsState()
    val progress by GestureState.progress.collectAsState()
    val last by GestureState.lastAction.collectAsState()
    val error by GestureState.error.collectAsState()

    val cam = remember(tick) { hasCamera(ctx) }
    val notif = remember(tick) { hasNotif(ctx) }
    val a11y = remember(tick) { isA11yEnabled(ctx) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        tick++
        if (hasCamera(ctx)) {
            Prefs.setEnabled(ctx, true)
            GestureService.start(ctx)
        }
    }

    fun toggle(on: Boolean) {
        if (!on) {
            Prefs.setEnabled(ctx, false)
            GestureService.stop(ctx)
            return
        }
        val need = ArrayList<String>()
        if (!hasCamera(ctx)) need.add(Manifest.permission.CAMERA)
        if (!hasNotif(ctx)) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isNotEmpty()) {
            launcher.launch(need.toTypedArray())
        } else {
            Prefs.setEnabled(ctx, true)
            GestureService.start(ctx)
        }
    }

    var hold by remember { mutableFloatStateOf(Prefs.holdMs(ctx) / 1000f) }
    var vib by remember { mutableStateOf(Prefs.vibrate(ctx)) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("EDİTH", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Hareket algılama", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text(
                            if (running) "Ön kamera izliyor" else "Kapalı",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    Switch(checked = running, onCheckedChange = { toggle(it) })
                }
                error?.let {
                    Spacer(Modifier.height(8.dp))
                    Text(it, color = MaterialTheme.colorScheme.error)
                }
                if (running) {
                    Spacer(Modifier.height(12.dp))
                    Text("Şu an görülen: ${current?.title ?: "el yok"}", fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(6.dp))
                    LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                    if (last.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        Text("Son işlem: $last", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("İzinler", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                StatusRow("Kamera", cam, "İzin ver") {
                    launcher.launch(arrayOf(Manifest.permission.CAMERA))
                }
                if (Build.VERSION.SDK_INT >= 33) {
                    StatusRow("Bildirim", notif, "İzin ver") {
                        launcher.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
                    }
                }
                StatusRow("Erişilebilirlik (ana ekran, geri, kaydırma vb. için)", a11y, "Aç") {
                    ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
                if (!a11y) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Erişilebilirlik ayarında \"EDİTH\" öğesini aç. Telefon \"Kısıtlı ayar\" diyerek izin vermezse: " +
                            "Uygulama bilgisi sayfasında sağ üstteki ⋮ menüsünden \"Kısıtlı ayarlara izin ver\" seç, sonra tekrar dene.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    TextButton(onClick = {
                        ctx.startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }) { Text("Uygulama bilgisini aç") }
                }
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Ayarlar", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text("Bekleme süresi: ${"%.1f".format(hold)} sn")
                Text("Duran bir hareketi kaç saniye tutman gerektiği.", style = MaterialTheme.typography.bodySmall)
                Slider(
                    value = hold,
                    onValueChange = { hold = it },
                    onValueChangeFinished = { Prefs.setHoldMs(ctx, (hold * 1000).toLong()) },
                    valueRange = 0.4f..2f,
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Komut olunca titret", Modifier.weight(1f))
                    Switch(checked = vib, onCheckedChange = { vib = it; Prefs.setVibrate(ctx, it) })
                }
            }
        }
    }
}

@Composable
fun InfoScreen() {
    val ctx = LocalContext.current
    val maps = remember {
        mutableStateMapOf<Gesture, Mapping>().apply {
            Gesture.values().forEach { put(it, Prefs.mapping(ctx, it)) }
        }
    }
    var editing by remember { mutableStateOf<Gesture?>(null) }
    var confirmReset by remember { mutableStateOf(false) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item { Text("Bilgi", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Nasıl kullanılır?", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text("• Ayarlar sekmesinden \"Hareket algılama\" anahtarını aç.")
                    Text("• Elini ön kameraya 30-60 cm uzaklıkta, iyi ışıkta tut.")
                    Text("• Duran hareketleri ayarlardaki süre kadar sabit tut. Kaydırma ve el sallamayı hızlıca yap.")
                    Text("• Bir komuttan sonra yaklaşık 1 saniye yeni komut alınmaz. Aynı hareketi tekrar yapmak için önce elini indir veya başka hareket yap.")
                    Text("• Bir hareketin anlamını değiştirmek için kartına dokun.")
                    Text("• Kamera çalışırken telefondaki yeşil kamera noktası yanar, bu normaldir.")
                }
            }
        }
        Group.values().forEach { grp ->
            item(key = grp.name) {
                Text(grp.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 8.dp))
            }
            items(Gesture.values().filter { it.group == grp }, key = { it.name }) { g ->
                Card(Modifier.fillMaxWidth()) {
                    Row(
                        Modifier.fillMaxWidth().clickable { editing = g }.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        HandIcon(g.icon, Modifier.size(76.dp))
                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text(g.title, fontWeight = FontWeight.SemiBold)
                            Text(g.how, style = MaterialTheme.typography.bodySmall)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "Anlamı: " + (maps[g] ?: Mapping(ActionType.NONE)).describe(ctx),
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Medium,
                            )
                        }
                        Icon(Icons.Filled.Edit, "Değiştir")
                    }
                }
            }
        }
        item {
            OutlinedButton(onClick = { confirmReset = true }, modifier = Modifier.fillMaxWidth()) {
                Text("Tüm anlamları varsayılana döndür")
            }
        }
    }

    editing?.let { g ->
        EditDialog(
            g = g,
            initial = maps[g] ?: Mapping(ActionType.NONE),
            onDismiss = { editing = null },
            onSave = { m ->
                Prefs.setMapping(ctx, g, m)
                maps[g] = m
                editing = null
            },
        )
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Varsayılana dön?") },
            text = { Text("Tüm hareketlerin anlamı ilk haline dönecek.") },
            confirmButton = {
                TextButton(onClick = {
                    Prefs.resetMappings(ctx)
                    Gesture.values().forEach { maps[it] = Prefs.mapping(ctx, it) }
                    confirmReset = false
                }) { Text("Evet") }
            },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Vazgeç") } },
        )
    }
}

@Composable
fun EditDialog(g: Gesture, initial: Mapping, onDismiss: () -> Unit, onSave: (Mapping) -> Unit) {
    var type by remember { mutableStateOf(initial.type) }
    var arg by remember { mutableStateOf(initial.arg) }
    var pickApp by remember { mutableStateOf(false) }
    val ctx = LocalContext.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("${g.title} ne yapsın?") },
        text = {
            LazyColumn(Modifier.heightIn(max = 420.dp)) {
                items(ActionType.values().toList()) { t ->
                    Row(
                        Modifier.fillMaxWidth().clickable {
                            type = t
                            arg = if (t == initial.type) initial.arg else ""
                        },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = type == t, onClick = {
                            type = t
                            arg = if (t == initial.type) initial.arg else ""
                        })
                        Text(t.label + if (t.needsA11y) " *" else "")
                    }
                }
                item {
                    if (type == ActionType.OPEN_APP) {
                        Column(Modifier.padding(top = 8.dp)) {
                            Text(if (arg.isBlank()) "Uygulama seçilmedi" else appLabel(ctx, arg))
                            OutlinedButton(onClick = { pickApp = true }) { Text("Uygulama seç") }
                        }
                    }
                    if (type == ActionType.OPEN_URL) {
                        OutlinedTextField(
                            value = arg, onValueChange = { arg = it },
                            label = { Text("Web adresi (örn. youtube.com)") },
                            singleLine = true,
                            modifier = Modifier.padding(top = 8.dp).fillMaxWidth(),
                        )
                    }
                    Text(
                        "* Erişilebilirlik izni gerekir",
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(top = 8.dp),
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = !((type == ActionType.OPEN_APP || type == ActionType.OPEN_URL) && arg.isBlank()),
                onClick = { onSave(Mapping(type, arg.trim())) },
            ) { Text("Kaydet") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Vazgeç") } },
    )

    if (pickApp) {
        AppPickerDialog(onPick = { arg = it; pickApp = false }, onDismiss = { pickApp = false })
    }
}

@Composable
fun AppPickerDialog(onPick: (String) -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf<List<Pair<String, String>>?>(null) }
    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) {
            val pm = ctx.packageManager
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pm.queryIntentActivities(i, 0)
                .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
                .distinctBy { it.second }
                .sortedBy { it.first.lowercase() }
        }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Uygulama seç") },
        text = {
            val list = apps
            if (list == null) {
                CircularProgressIndicator()
            } else {
                LazyColumn(Modifier.heightIn(max = 420.dp)) {
                    items(list) { (label, pkg) ->
                        Text(
                            label,
                            Modifier.fillMaxWidth().clickable { onPick(pkg) }.padding(vertical = 12.dp),
                        )
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Vazgeç") } },
    )
}
