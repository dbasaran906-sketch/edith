package com.elhareket.app

import kotlin.math.abs
import kotlin.math.hypot

/**
 * Kare kare gelen el noktalarından "tutma" ve "hareket" komutlarını çıkarır.
 * Aynı komut art arda tetiklenmesin diye hareket bırakılana kadar kilitlenir.
 */
class GestureEngine(private val onFire: (Gesture) -> Unit) {
    var holdMs = 800L
    private val cooldownMs = 1200L

    private var cand: Gesture? = null
    private var candSince = 0L
    private var candX = 0f
    private var candY = 0f
    private var latch: Gesture? = null
    private var lastFire = -100000L

    private class S(val t: Long, val x: Float, val y: Float, val hs: Float)

    private val hist = ArrayDeque<S>()

    private fun publish(g: Gesture?, p: Float) {
        if (GestureState.current.value != g) GestureState.current.value = g
        if (abs(GestureState.progress.value - p) > 0.04f || p == 0f) GestureState.progress.value = p
    }

    private fun lost() {
        cand = null
        latch = null
        hist.clear()
        publish(null, 0f)
    }

    fun update(now: Long, hands: List<List<Pt>>) {
        if (hands.isEmpty() || hands[0].size < 21) { lost(); return }
        val h0 = hands[0]
        val hs = Classifier.handSize(h0)
        if (hs < 0.02f) { lost(); return }

        var g = Classifier.classify(h0)
        if (hands.size >= 2 && hands[1].size >= 21) {
            val g1 = Classifier.classify(hands[1])
            if (g == Gesture.OPEN_PALM && g1 == Gesture.OPEN_PALM) g = Gesture.TWO_OPEN
            else if (g == Gesture.FIST && g1 == Gesture.FIST) g = Gesture.TWO_FISTS
            else if (g == null) g = g1
        }

        val p = h0[9]
        hist.addLast(S(now, p.x, p.y, hs))
        while (hist.isNotEmpty() && now - hist.first().t > 1300) hist.removeFirst()

        if (g != latch) latch = null

        if (now - lastFire < cooldownMs) {
            cand = null
            publish(g, 0f)
            return
        }

        if (hands.size == 1 && Classifier.openLike(h0)) {
            val dyn = detectDynamic(now)
            if (dyn != null) {
                lastFire = now
                latch = g
                hist.clear()
                cand = null
                publish(g, 0f)
                onFire(dyn)
                return
            }
        }

        if (g == null || g == latch) {
            cand = null
            publish(g, 0f)
            return
        }

        if (g != cand) {
            cand = g; candSince = now; candX = p.x; candY = p.y
        } else if (hypot(p.x - candX, p.y - candY) > hs) {
            candSince = now; candX = p.x; candY = p.y
        }

        val prog = ((now - candSince).toFloat() / holdMs).coerceIn(0f, 1f)
        publish(g, prog)
        if (now - candSince >= holdMs) {
            lastFire = now
            latch = g
            cand = null
            onFire(g)
        }
    }

    private fun detectDynamic(now: Long): Gesture? {
        if (hist.size < 4) return null
        val hsAvg = hist.map { it.hs }.average().toFloat()

        // El sallama: yatayda en az 3 yön değişimi
        val thr = 0.4f * hsAvg
        var dir = 0
        var ext = hist.first().x
        var rev = 0
        for (s in hist) {
            when (dir) {
                0 -> {
                    if (s.x - ext > thr) { dir = 1; ext = s.x }
                    else if (ext - s.x > thr) { dir = -1; ext = s.x }
                }
                1 -> {
                    if (s.x > ext) ext = s.x
                    else if (ext - s.x > thr) { dir = -1; rev++; ext = s.x }
                }
                else -> {
                    if (s.x < ext) ext = s.x
                    else if (s.x - ext > thr) { dir = 1; rev++; ext = s.x }
                }
            }
        }
        if (rev >= 3) return Gesture.WAVE

        // Kaydırma: son yarım saniyede tek yönlü büyük yer değiştirme
        val recent = hist.filter { now - it.t <= 500 }
        if (recent.size < 3) return null
        val a = recent.first()
        val b = recent.last()
        val dx = b.x - a.x
        val dy = b.y - a.y
        var pathX = 0f
        var pathY = 0f
        for (i in 1 until recent.size) {
            pathX += abs(recent[i].x - recent[i - 1].x)
            pathY += abs(recent[i].y - recent[i - 1].y)
        }
        if (abs(dx) > 1.8f * hsAvg && abs(dx) > 2f * abs(dy) && pathX < 1.6f * abs(dx)) {
            return if (dx > 0) Gesture.SWIPE_RIGHT else Gesture.SWIPE_LEFT
        }
        if (abs(dy) > 1.6f * hsAvg && abs(dy) > 2f * abs(dx) && pathY < 1.6f * abs(dy)) {
            return if (dy > 0) Gesture.SWIPE_DOWN else Gesture.SWIPE_UP
        }
        return null
    }
}
