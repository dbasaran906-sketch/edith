package com.elhareket.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class GestureService : LifecycleService() {

    companion object {
        const val ACTION_STOP = "com.elhareket.app.STOP"
        private const val CHANNEL = "el_hareket"
        private const val NOTIF_ID = 42
        private const val TAG = "GestureService"

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, GestureService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, GestureService::class.java))
        }
    }

    private var landmarker: HandLandmarker? = null
    private var executor: ExecutorService? = null
    private var provider: ProcessCameraProvider? = null
    private val main = Handler(Looper.getMainLooper())
    private var lastTs = 0L
    private lateinit var engine: GestureEngine

    override fun onBind(intent: Intent): IBinder? {
        super.onBind(intent)
        return null
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)

        if (intent?.action == ACTION_STOP) {
            Prefs.setEnabled(this, false)
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            createChannel()
            ServiceCompat.startForeground(
                this, NOTIF_ID, buildNotification(),
                if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA else 0
            )
        } catch (e: Exception) {
            Log.e(TAG, "Önplan servisi başlatılamadı", e)
            GestureState.error.value = "Servis başlatılamadı: ${e.javaClass.simpleName}"
            Prefs.setEnabled(this, false)
            stopSelf()
            return START_NOT_STICKY
        }

        if (landmarker == null) {
            try {
                val base = BaseOptions.builder().setModelAssetPath("hand_landmarker.task").build()
                val opts = HandLandmarker.HandLandmarkerOptions.builder()
                    .setBaseOptions(base)
                    .setRunningMode(RunningMode.IMAGE)
                    .setNumHands(2)
                    .setMinHandDetectionConfidence(0.5f)
                    .setMinHandPresenceConfidence(0.5f)
                    .setMinTrackingConfidence(0.5f)
                    .build()
                landmarker = HandLandmarker.createFromOptions(this, opts)
            } catch (e: Exception) {
                Log.e(TAG, "Model yüklenemedi", e)
                GestureState.error.value = "El takip modeli yüklenemedi"
                Prefs.setEnabled(this, false)
                stopSelf()
                return START_NOT_STICKY
            }
        }

        engine = GestureEngine { g -> onGesture(g) }
        executor = Executors.newSingleThreadExecutor()
        GestureState.error.value = null
        GestureState.running.value = true
        startCamera()
        return START_NOT_STICKY
    }

    private fun onGesture(g: Gesture) {
        val m = Prefs.mapping(this, g)
        main.post {
            if (m.type == ActionType.NONE) {
                GestureState.lastAction.value = "${g.title}: atanmış işlem yok"
            } else {
                val msg = ActionExecutor.run(applicationContext, m)
                GestureState.lastAction.value = "${g.title} → $msg"
                if (Prefs.vibrate(this)) vibrate()
            }
        }
    }

    private fun vibrate() {
        try {
            val v: Vibrator = if (Build.VERSION.SDK_INT >= 31) {
                (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
            v.vibrate(VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {
        }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val p = future.get()
                provider = p
                val analysis = ImageAnalysis.Builder()
                    .setTargetResolution(Size(480, 640))
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                analysis.setAnalyzer(executor!!) { proxy -> analyze(proxy) }
                p.unbindAll()
                p.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
            } catch (e: Exception) {
                Log.e(TAG, "Kamera açılamadı", e)
                GestureState.error.value = "Ön kamera açılamadı"
                Prefs.setEnabled(this, false)
                stopSelf()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(proxy: ImageProxy) {
        try {
            val now = SystemClock.elapsedRealtime()
            if (now - lastTs < 90) return
            lastTs = now
            val lm = landmarker ?: return

            val raw = proxy.toBitmap()
            val m = Matrix().apply {
                postRotate(proxy.imageInfo.rotationDegrees.toFloat())
                postScale(-1f, 1f) // ayna: kullanıcının sağı = görüntünün sağı
            }
            val bmp = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
            val aspect = bmp.width.toFloat() / bmp.height.toFloat()
            val result = lm.detect(BitmapImageBuilder(bmp).build())
            val hands = result.landmarks().map { hand -> hand.map { Pt(it.x() * aspect, it.y()) } }

            engine.holdMs = Prefs.holdMs(this)
            engine.update(now, hands)
        } catch (e: Exception) {
            Log.e(TAG, "Kare işlenemedi", e)
        } finally {
            proxy.close()
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "El hareketi takibi", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, GestureService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("EDİTH izliyor")
            .setContentText("Ön kamera açık. Durdurmak için dokun.")
            .setContentIntent(open)
            .addAction(0, "Durdur", stop)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        GestureState.running.value = false
        GestureState.current.value = null
        GestureState.progress.value = 0f
        try { provider?.unbindAll() } catch (_: Exception) {}
        executor?.shutdown()
        try { landmarker?.close() } catch (_: Exception) {}
        landmarker = null
        super.onDestroy()
    }
}
