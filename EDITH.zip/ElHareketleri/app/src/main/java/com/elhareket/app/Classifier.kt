package com.elhareket.app

import kotlin.math.abs
import kotlin.math.hypot

/** Koordinat: x = yatay * (genişlik/yükseklik), y = dikey. Görüntü ayna çevrilmiş (x artışı = kullanıcının sağı). */
data class Pt(val x: Float, val y: Float)

object Classifier {
    private fun d(a: Pt, b: Pt) = hypot(a.x - b.x, a.y - b.y)

    fun handSize(l: List<Pt>) = d(l[0], l[9])

    private fun ext(l: List<Pt>, tip: Int, pip: Int) = d(l[tip], l[0]) > d(l[pip], l[0]) * 1.2f

    fun openLike(l: List<Pt>): Boolean {
        val c = listOf(ext(l, 8, 6), ext(l, 12, 10), ext(l, 16, 14), ext(l, 20, 18)).count { it }
        return c >= 3
    }

    private fun thumbDir(l: List<Pt>): Gesture? {
        val vx = l[4].x - l[2].x
        val vy = l[4].y - l[2].y
        val len = hypot(vx, vy)
        if (len < 1e-4f) return null
        return when {
            vy < -0.6f * len -> Gesture.THUMB_UP
            vy > 0.6f * len -> Gesture.THUMB_DOWN
            else -> null
        }
    }

    private fun indexDir(l: List<Pt>): Gesture? {
        val vx = l[8].x - l[5].x
        val vy = l[8].y - l[5].y
        return when {
            abs(vx) > abs(vy) -> if (vx > 0) Gesture.POINT_RIGHT else Gesture.POINT_LEFT
            vy < 0 -> Gesture.INDEX_UP
            else -> null
        }
    }

    fun classify(l: List<Pt>): Gesture? {
        if (l.size < 21) return null
        val hs = handSize(l)
        if (hs < 0.02f) return null

        val idx = ext(l, 8, 6)
        val mid = ext(l, 12, 10)
        val rng = ext(l, 16, 14)
        val pnk = ext(l, 20, 18)
        val thumb = d(l[4], l[5]) > 0.5f * hs

        if (d(l[4], l[8]) < 0.22f * hs) {
            if (mid && rng && pnk) return Gesture.OK
            if (!mid && !rng && !pnk && d(l[8], l[0]) > 0.85f * hs) return Gesture.PINCH
        }

        return when {
            idx && mid && rng && pnk -> if (thumb) Gesture.OPEN_PALM else Gesture.FOUR
            !idx && !mid && !rng && !pnk -> if (thumb) thumbDir(l) else Gesture.FIST
            idx && mid && rng && !pnk -> Gesture.THREE
            idx && mid && !rng && !pnk -> Gesture.VICTORY
            idx && !mid && !rng && !pnk -> if (thumb) Gesture.L_SHAPE else indexDir(l)
            !idx && !mid && !rng && pnk -> if (thumb) Gesture.SHAKA else Gesture.PINKY
            idx && !mid && !rng && pnk -> if (thumb) Gesture.LOVE else Gesture.ROCK
            else -> null
        }
    }
}
