package com.elhareket.app

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.KeyEvent
import android.widget.Toast

enum class ActionType(val label: String, val needsA11y: Boolean = false) {
    NONE("Hiçbir şey yapma"),
    HOME("Uygulamadan çık (ana ekran)", true),
    BACK("Geri git", true),
    RECENTS("Son uygulamaları aç", true),
    NOTIFICATIONS("Bildirim panelini aç", true),
    QUICK_SETTINGS("Hızlı ayarları aç", true),
    LOCK("Ekranı kilitle", true),
    SCREENSHOT("Ekran görüntüsü al", true),
    POWER_MENU("Güç menüsünü aç", true),
    OPEN_APP("Bir uygulama aç"),
    OPEN_URL("Bir web sayfası aç"),
    VOLUME_UP("Sesi artır"),
    VOLUME_DOWN("Sesi azalt"),
    MUTE("Sesi kapat / aç"),
    PLAY_PAUSE("Müzik / video oynat-durdur"),
    NEXT("Sonraki parça"),
    PREV("Önceki parça"),
    FLASH("El fenerini aç / kapat"),
    SCROLL_DOWN("Sayfayı aşağı kaydır", true),
    SCROLL_UP("Sayfayı yukarı kaydır", true),
    SWIPE_LEFT("Sola kaydır (sonraki sayfa)", true),
    SWIPE_RIGHT("Sağa kaydır (önceki sayfa)", true),
}

data class Mapping(val type: ActionType, val arg: String = "") {
    fun encode() = "${type.name}|$arg"

    fun describe(ctx: Context): String = when (type) {
        ActionType.OPEN_APP -> if (arg.isBlank()) "Uygulama seçilmedi" else "Aç: " + appLabel(ctx, arg)
        ActionType.OPEN_URL -> if (arg.isBlank()) "Adres girilmedi" else "Sayfa aç: $arg"
        else -> type.label
    }

    companion object {
        fun decode(s: String?): Mapping? {
            if (s == null) return null
            val i = s.indexOf('|')
            val name = if (i >= 0) s.substring(0, i) else s
            val arg = if (i >= 0) s.substring(i + 1) else ""
            val t = ActionType.values().firstOrNull { it.name == name } ?: return null
            return Mapping(t, arg)
        }
    }
}

fun appLabel(ctx: Context, pkg: String): String = try {
    val pm = ctx.packageManager
    pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
} catch (e: Exception) {
    pkg
}

val DEFAULT_MAPPINGS: Map<Gesture, Mapping> = mapOf(
    Gesture.FIST to Mapping(ActionType.HOME),
    Gesture.OPEN_PALM to Mapping(ActionType.NONE),
    Gesture.INDEX_UP to Mapping(ActionType.BACK),
    Gesture.VICTORY to Mapping(ActionType.SCREENSHOT),
    Gesture.THREE to Mapping(ActionType.RECENTS),
    Gesture.FOUR to Mapping(ActionType.NOTIFICATIONS),
    Gesture.THUMB_UP to Mapping(ActionType.VOLUME_UP),
    Gesture.THUMB_DOWN to Mapping(ActionType.VOLUME_DOWN),
    Gesture.OK to Mapping(ActionType.PLAY_PAUSE),
    Gesture.ROCK to Mapping(ActionType.FLASH),
    Gesture.SHAKA to Mapping(ActionType.MUTE),
    Gesture.L_SHAPE to Mapping(ActionType.QUICK_SETTINGS),
    Gesture.LOVE to Mapping(ActionType.NONE),
    Gesture.PINKY to Mapping(ActionType.NONE),
    Gesture.PINCH to Mapping(ActionType.NONE),
    Gesture.POINT_RIGHT to Mapping(ActionType.NEXT),
    Gesture.POINT_LEFT to Mapping(ActionType.PREV),
    Gesture.TWO_OPEN to Mapping(ActionType.NONE),
    Gesture.TWO_FISTS to Mapping(ActionType.LOCK),
    Gesture.SWIPE_RIGHT to Mapping(ActionType.SWIPE_RIGHT),
    Gesture.SWIPE_LEFT to Mapping(ActionType.SWIPE_LEFT),
    Gesture.SWIPE_UP to Mapping(ActionType.SCROLL_DOWN),
    Gesture.SWIPE_DOWN to Mapping(ActionType.SCROLL_UP),
    Gesture.WAVE to Mapping(ActionType.NONE),
)

object Prefs {
    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("el_prefs", Context.MODE_PRIVATE)

    fun enabled(c: Context) = sp(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()

    fun holdMs(c: Context) = sp(c).getLong("hold", 800L)
    fun setHoldMs(c: Context, v: Long) = sp(c).edit().putLong("hold", v).apply()

    fun vibrate(c: Context) = sp(c).getBoolean("vib", true)
    fun setVibrate(c: Context, v: Boolean) = sp(c).edit().putBoolean("vib", v).apply()

    fun mapping(c: Context, g: Gesture): Mapping =
        Mapping.decode(sp(c).getString("map_${g.name}", null)) ?: DEFAULT_MAPPINGS[g] ?: Mapping(ActionType.NONE)

    fun setMapping(c: Context, g: Gesture, m: Mapping) =
        sp(c).edit().putString("map_${g.name}", m.encode()).apply()

    fun resetMappings(c: Context) {
        val e = sp(c).edit()
        Gesture.values().forEach { e.remove("map_${it.name}") }
        e.apply()
    }
}

fun isA11yEnabled(ctx: Context): Boolean {
    val s = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
    val cn = ComponentName(ctx, GestureAccessibilityService::class.java)
    val full = cn.flattenToString()
    val short = cn.flattenToShortString()
    return s.split(':').any { it.equals(full, true) || it.equals(short, true) }
}

object ActionExecutor {
    private val main = Handler(Looper.getMainLooper())
    private var torchOn = false

    private fun toast(ctx: Context, msg: String) = main.post { Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show() }

    /** Yapılan işi anlatan kısa bir metin döndürür. */
    fun run(ctx: Context, m: Mapping): String {
        val svc = GestureAccessibilityService.instance
        if (m.type.needsA11y && svc == null) {
            toast(ctx, "Erişilebilirlik izni kapalı: Ayarlar sekmesinden aç")
            return "Erişilebilirlik izni gerekli"
        }
        val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        when (m.type) {
            ActionType.NONE -> {}
            ActionType.HOME -> svc!!.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
            ActionType.BACK -> svc!!.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            ActionType.RECENTS -> svc!!.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)
            ActionType.NOTIFICATIONS -> svc!!.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
            ActionType.QUICK_SETTINGS -> svc!!.performGlobalAction(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
            ActionType.LOCK -> svc!!.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
            ActionType.SCREENSHOT -> svc!!.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
            ActionType.POWER_MENU -> svc!!.performGlobalAction(AccessibilityService.GLOBAL_ACTION_POWER_DIALOG)
            ActionType.SCROLL_DOWN -> svc!!.swipe(0.5f, 0.72f, 0.5f, 0.28f)
            ActionType.SCROLL_UP -> svc!!.swipe(0.5f, 0.28f, 0.5f, 0.72f)
            ActionType.SWIPE_LEFT -> svc!!.swipe(0.85f, 0.5f, 0.15f, 0.5f)
            ActionType.SWIPE_RIGHT -> svc!!.swipe(0.15f, 0.5f, 0.85f, 0.5f)
            ActionType.OPEN_APP -> {
                val i = ctx.packageManager.getLaunchIntentForPackage(m.arg)
                if (i == null) { toast(ctx, "Uygulama bulunamadı"); return "Uygulama bulunamadı" }
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { (svc ?: ctx).startActivity(i) } catch (e: Exception) { toast(ctx, "Uygulama açılamadı"); return "Uygulama açılamadı" }
            }
            ActionType.OPEN_URL -> {
                var u = m.arg.trim()
                if (!u.contains("://")) u = "https://$u"
                val i = Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { (svc ?: ctx).startActivity(i) } catch (e: Exception) { toast(ctx, "Sayfa açılamadı"); return "Sayfa açılamadı" }
            }
            ActionType.VOLUME_UP -> audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            ActionType.VOLUME_DOWN -> audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            ActionType.MUTE -> audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, AudioManager.FLAG_SHOW_UI)
            ActionType.PLAY_PAUSE -> media(audio, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
            ActionType.NEXT -> media(audio, KeyEvent.KEYCODE_MEDIA_NEXT)
            ActionType.PREV -> media(audio, KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            ActionType.FLASH -> toggleTorch(ctx)
        }
        return m.describe(ctx)
    }

    private fun media(audio: AudioManager, code: Int) {
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun toggleTorch(ctx: Context) {
        try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                val c = cm.getCameraCharacteristics(it)
                c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            } ?: run { toast(ctx, "Fener bulunamadı"); return }
            torchOn = !torchOn
            cm.setTorchMode(id, torchOn)
        } catch (e: Exception) {
            toast(ctx, "Fener açılamadı")
        }
    }
}
